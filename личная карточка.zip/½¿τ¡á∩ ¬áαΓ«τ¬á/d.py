from flask import Flask, render_template
import json
import random
app = Flask(__name__)



@app.route('/member')
def index():
    with open('templates/qq.json') as f:
        data = json.load(f)
    sp = [i for i in data.keys()]
    cluch = random.choice(sp)
    name = data[cluch]['name']
    surname = data[cluch]['surname']
    photo = data[cluch]['photo']
    prof = data[cluch]['prof']
    prof.sort()
    return render_template('index.html', namefamil=f'{name} {surname}',
                           put=photo, prof=', '.join(prof))








if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')